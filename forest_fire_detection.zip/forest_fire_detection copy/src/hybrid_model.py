import torch
import torch.nn as nn
import timm


class _TransformerEncoder(nn.Module):
    """Lightweight Transformer encoder with a learnable CLS token."""

    def __init__(
        self,
        embed_dim: int,
        num_heads: int,
        num_layers: int,
        mlp_ratio: float = 4.0,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=int(embed_dim * mlp_ratio),
            dropout=dropout,
            batch_first=True,
            norm_first=True,   # pre-LN is more stable
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        # tokens: [B, N, embed_dim]
        B = tokens.size(0)
        cls = self.cls_token.expand(B, -1, -1)          # [B, 1, embed_dim]
        x = torch.cat([cls, tokens], dim=1)              # [B, N+1, embed_dim]
        x = self.encoder(x)
        return self.norm(x[:, 0])                        # CLS token output [B, embed_dim]


class HybridCNNTransformer(nn.Module):
    """Hybrid model: CNN backbone for local features + Transformer for global context.

    Architecture:
        Input (224×224×3)
        → CNN backbone (EfficientNet-B4)  →  feature map [B, C, H, W]
        → 1×1 Conv projection             →  [B, embed_dim, H, W]
        → flatten + positional embedding  →  tokens [B, H*W, embed_dim]
        → Transformer encoder             →  CLS token [B, embed_dim]
        → Dropout + Linear                →  logits [B, num_classes]
    """

    def __init__(
        self,
        num_classes: int = 2,
        backbone: str = 'efficientnet_b4',
        pretrained: bool = True,
        embed_dim: int = 512,
        num_heads: int = 8,
        num_layers: int = 4,
        dropout: float = 0.3,
    ):
        super().__init__()

        # CNN feature extractor (no head, no global pool)
        self.cnn = timm.create_model(backbone, pretrained=pretrained,
                                     num_classes=0, global_pool='')
        feat_dim = self.cnn.num_features          # e.g. 1792 for EfficientNet-B4

        # Project CNN feature maps to Transformer embedding dimension
        self.proj = nn.Sequential(
            nn.Conv2d(feat_dim, embed_dim, kernel_size=1, bias=False),
            nn.BatchNorm2d(embed_dim),
        )

        # Positional embedding: max 196 patches (14×14) + 1 CLS (added inside encoder)
        self.pos_embed = nn.Parameter(torch.zeros(1, 196, embed_dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        self.transformer = _TransformerEncoder(
            embed_dim=embed_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            dropout=dropout,
        )
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(embed_dim, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Extract feature map
        feat = self.cnn(x)                              # [B, C, H, W]
        feat = self.proj(feat)                          # [B, embed_dim, H, W]
        B, C, H, W = feat.shape
        N = H * W

        # Flatten spatial dims → token sequence
        tokens = feat.flatten(2).permute(0, 2, 1)      # [B, N, embed_dim]
        tokens = tokens + self.pos_embed[:, :N, :]     # add positional embedding

        cls_out = self.transformer(tokens)              # [B, embed_dim]
        return self.classifier(cls_out)

    def freeze_backbone(self) -> None:
        for p in self.cnn.parameters():
            p.requires_grad = False

    def unfreeze_backbone(self) -> None:
        for p in self.cnn.parameters():
            p.requires_grad = True

    def get_transformer_attention(self, x: torch.Tensor, layer_idx: int = -1):
        """Return attention weights from the specified Transformer layer for visualization."""
        attn_output = {}

        # PyTorch 2.x calls self_attn with need_weights=False internally, so out[1]
        # is always None. Use a pre-hook to re-run attention with need_weights=True.
        def pre_hook(module, inp):
            q, k, v = inp[0], inp[1], inp[2]
            with torch.no_grad():
                _, weights = module(q, k, v, need_weights=True, average_attn_weights=False)
            attn_output['weights'] = weights  # [B, num_heads, N+1, N+1]

        layers = list(self.transformer.encoder.layers)
        handle = layers[layer_idx].self_attn.register_forward_pre_hook(pre_hook)
        with torch.no_grad():
            self(x)
        handle.remove()
        return attn_output.get('weights')   # [B, num_heads, N+1, N+1]
